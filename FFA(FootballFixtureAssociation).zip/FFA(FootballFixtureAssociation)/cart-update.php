<?php
// cart-update.php
require 'include/common.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the increase_quantity parameter is set
    if (isset($_POST["increase_quantity"]) && isset($_POST["product_id"])) {
        // Retrieve the product ID from the form
        $product_id = $_POST["product_id"];
        
        // Get the current quantity from the database
        $result = mysqli_query($con, "SELECT * FROM users_items WHERE user_id = '$user_id' AND product_id = '$product_id'");
        $row = mysqli_fetch_array($result);
        $quantity = $row['quantity'];
        
        // Increase the quantity by 1
        $quantity++;
        
        // Update the quantity in the database for the specified product
        mysqli_query($con, "UPDATE users_items SET quantity = '$quantity' WHERE user_id = '$user_id' AND product_id = '$product_id'");
        
        // Redirect back to the cart page after updating the quantity
        header("Location: cart.php");
        exit();
    }
}
?>
