<?php 
   session_start();

   include("php/config.php");
   if(!isset($_SESSION['valid'])){
    header("Location: index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Football Fixture Website</title>
    <link rel="stylesheet" href="style/home.css">
 <style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>

    <div class="navbar">
        <div class="logo">
            <a href="home.php">FFA</a>
        </div>
        <div class="nav-links">
            <a href="Fixture.html">Fixture</a>
            <a href="Store.html">Store</a>
            <a href="Cart.html">Cart</a>
            <a href="Wishlist.html">Wishlist</a>
            <a href="php/logout.php"> <button class="logout-btn">Log Out</button> </a>

        </div>
    </div>
    <!-- Page content -->
<div class="w3-content" style="max-width:2000px">

<!-- Automatic Slideshow Images -->
<div class="mySlides w3-display-container w3-center">
  <img src="https://assets.architecturaldigest.in/photos/60082342345ead69c9c1aeb6/16:9/w_2560%2Cc_limit/FIFA-2018-World-Cup-Featured-1366x768.jpg" style="width:100%;height: 50%;">
  <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
    <h3>FIFA WORLD CUP 2022</h3>
    <p><b></b></p>   
  </div>
</div>
<div class="mySlides w3-display-container w3-center">
  <img src="https://images2.minutemediacdn.com/image/upload/c_crop,w_4282,h_2408,x_0,y_206/c_fill,w_1440,ar_16:9,f_auto,q_auto,g_auto/images/GettyImages/mmsport/90min_en_international_web/01gmdt39z71gagrxrhpn.jpg" style="width:100%">
  <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
    <h3>Argentina Team</h3>
    <p><b>Into the finals lets go !!!</b></p>    
  </div>
</div>
<div class="mySlides w3-display-container w3-center">
  <img src="https://i0.wp.com/news.paddypower.com/assets/uploads/2022/10/France-national-football-team.jpg?fit=1920%2C1256&ssl=1" style="width:100%">
  <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
    <h3>France Team</h3>
    <p><b>Into the finals lets go !!!</b></p>    
  </div>
</div>

<!-- The Band Section -->
<div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
  <h2 class="w3-wide">FFA</h2>
  <p class="w3-opacity"><i>We love Football</i></p>
  <p class="w3-justify">
    Welcome to Football Website! We are passionate about football and aim to provide high-quality football merchandise to fans around the world.
    Our mission is to offer a wide range of football jerseys, footballs, and accessories from top brands at affordable prices.
    Website also does includes fixtures and standings for the FIFA WORLD CUP 2022.
    <div class="w3-row w3-padding-32">
    <div class="w3-third">
      <p>Home Lander Page</p>
      <img src="home.png" class="w3-round w3-margin-bottom" alt="Random Name" style="width:60%;height:50%"><br><br>
      <p></p>
    </div>
    <div class="w3-third">
      <p>Accesories</p>
      <img src="acc.png" alt="Random Name" style="width:60%;height:50%"><br><br>
      <p></p></div>
    <div class="w3-third">
      <p>Fixtures</p>
      <img src="map.png" class="w3-round w3-margin-bottom" alt="Random Name" style="width:60%;height:50%"><br><br>
      <p></p></div>
  </div>
</div>

<!-- The Tour Section -->
<div class="w3-black" id="tour">
  <div class="w3-container w3-content w3-padding-64" style="max-width:800px">
    <h2 class="w3-wide w3-center">FIFA WORLD CUP 2022 - FINALS</h2>
    <p class="w3-opacity w3-center"><i>Remember to book your tickets!</i></p><br>

    <ul class="w3-ul w3-border w3-white w3-text-grey">
      <li class="w3-padding">Map Information <span class="w3-badge w3-right w3-margin-right">69</span></li>
    </ul>

    <div class="w3-row-padding w3-padding-32" style="margin:0 -16px">
      <div class="w3-third w3-margin-bottom">
      <iframe 
        width="600" 
        height="450" 
        frameborder="0" 
        style="border:0" 
        src="https://www.openstreetmap.org/export/embed.html?bbox=-74.0671%2C40.70%2C-73.8337%2C40.8779&amp;layer=mapnik">
    </iframe>
        <div class="w3-container w3-white">
          <p><b>Qatar - Lusail Stadium ,Doha</b></p>
          <p class="w3-opacity">18 Dec 2022</p>
          <p>Dont miss out the fun you gonna enoy.</p>
          <button class="w3-button w3-black w3-margin-bottom" onclick="document.getElementById('ticketModal').style.display='block'">Buy Tickets</button>
        </div>
      </div>
    </div>
      </div>
    </div>
  </div>
</div>

<!-- The Contact Section -->
<div class="w3-container w3-content w3-padding-64" style="max-width:800px" id="contact">
  <h2 class="w3-wide w3-center">CONTACT</h2>
  <p class="w3-opacity w3-center"><i>Fan? Drop a note!</i></p>
  <div class="w3-row w3-padding-32">
    <div class="w3-col m6 w3-large w3-margin-bottom">
      <i class="fa fa-map-marker" style="width:30px"></i> Pune, Bavdhan<br>
      <i class="fa fa-phone" style="width:30px"></i> Phone: +91 83560 69696<br>
      <i class="fa fa-envelope" style="width:30px"> </i> Email: ffa@gmail.com<br>
    </div>
    <div class="w3-col m6">
      <form action="#" target="_blank">
        <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
          <div class="w3-half">
            <input class="w3-input w3-border" type="text" placeholder="Name" required name="Name">
          </div>
          <div class="w3-half">
            <input class="w3-input w3-border" type="text" placeholder="Email" required name="Email">
          </div>
        </div>
        <input class="w3-input w3-border" type="text" placeholder="Message" required name="Message">
        <button class="w3-button w3-black w3-section w3-right" type="submit">SEND</button>
      </form>
    </div>
  </div>
</div>

<!-- End Page Content -->
</div>


<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity w3-light-grey w3-xlarge">
<i class="fa fa-facebook-official w3-hover-opacity"></i>
<i class="fa fa-instagram w3-hover-opacity"></i>
<i class="fa fa-snapchat w3-hover-opacity"></i>
<i class="fa fa-pinterest-p w3-hover-opacity"></i>
<i class="fa fa-twitter w3-hover-opacity"></i>
<i class="fa fa-linkedin w3-hover-opacity"></i>
<p class="w3-medium">Powered by <a href="https://www.fifa.com/fifaplus/en/tournaments/mens/worldcup/qatar2022" target="_blank">FFA</a></p>
</footer>

<script>
// Automatic Slideshow - change image every 4 seconds
var myIndex = 0;
carousel();

function carousel() {
var i;
var x = document.getElementsByClassName("mySlides");
for (i = 0; i < x.length; i++) {
  x[i].style.display = "none";  
}
myIndex++;
if (myIndex > x.length) {myIndex = 1}    
x[myIndex-1].style.display = "block";  
setTimeout(carousel, 4000);    
}

// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
var x = document.getElementById("navDemo");
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
} else { 
  x.className = x.className.replace(" w3-show", "");
}
}

// When the user clicks anywhere outside of the modal, close it
var modal = document.getElementById('ticketModal');
window.onclick = function(event) {
if (event.target == modal) {
  modal.style.display = "none";
}
}
</script>

</body>
</html>


