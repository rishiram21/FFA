<!DOCTYPE html>
<html>
    <head>
         <?php
include 'include\common.php';

?>
        <title>FFA</title>
<style>
body{
    background-color: LightGray;
}
.footer {
    background-color: #333;
    color: #fff;
    padding: 20px 0;
    text-align: center;
}

.footer p {
    margin: 0;
}

</style>
    </head>
    <body>
        <?php include 'search_form.php';?>
       <div class="container">
            <div class="jumbotron" style="text-align: center;">
                <!-- main page -->
        <div class="main">
            <div class="mainText">
                <h1>Football Fashion For Always</h1>
                <p>Get your all football related accesories here.</p>
            </div>
        </div>
        
        <!-- shopping card -->

        <div class="shop" id="shop">
            <div class="head">
            <hr noshade height="10%">
                <h3>FIFA WORLD CUP <span>2022 - Jersey's Available Now</span></h3>
            <hr noshade height="10%">
            </div></div>
        </div>
        <div class='container'>
            <?php                    
            require_once 'include/Check-if-added.php';  
        $query=mysqli_query($con, "SELECT * FROM products ; ") ;
        while ($row = mysqli_fetch_array($query)) { ?>
            <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
        <?php echo"<img src='admin/Image/".$row['image']."'class='img-thumbnail' >";?>
                        <div class="caption">
                            <?php echo "<a href='product_detail.php?id=".$row['id']."'><h4>".$row['name']." ".$row['brand']."</h4></a>"; ?>
                            <p>Price: ₹ <?php echo $row['price'] ;  ?> </p>
                        </div>
                    </div>
            </div>
                <?php } ?>
        </div> 
                <footer class="footer">
        <div class="container">
            <p>&copy; FFA - Football Fixture Association. All rights reserved.</p>
        </div>
    </footer>
                            
        
    </body>
</html>
