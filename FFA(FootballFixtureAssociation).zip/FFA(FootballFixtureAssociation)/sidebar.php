
    
                <div class="col-sm-3 ">
                    <div class="sidebar padding">
                    <div class='well'>
                        <img src='ll' class='img-circle' alt="Profile Picture">
                        <div ><?php echo "<div>Hello "."<span class=header>".ucwords($row['name'])."</span>"."</div>"; ?></div>
                    </div>
                        <a href="profile.php"><div class="well header">Profile Information</div></a>
                        <a href="manage_address.php"><div class="well header">Manage Address</div></a>
                        <a href="favorite.php"><div class="well header">Favorite</div></a>
                        <a href="support.php"><div class="well header">Support</div></a>
                        <a href="cart.php"><div class="well header">View cart</div></a>
                        <a href="my_order.php"><div class="well header">My Orders</div></a>
                        <br>
                    </div>
                </div>
               
            
    